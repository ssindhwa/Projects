public class iiscPavUtil {
    public static int random() {
        return 0;
    }
    static int i =0;
    static void p() {
        if (i <= 5) {
            i=i+1;
        }
    }
}


