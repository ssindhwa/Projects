export CLASSPATH=".:pkgs/soot-4.3.0-with-deps.jar"
