rm -rf *.dot
rm -rf output.png